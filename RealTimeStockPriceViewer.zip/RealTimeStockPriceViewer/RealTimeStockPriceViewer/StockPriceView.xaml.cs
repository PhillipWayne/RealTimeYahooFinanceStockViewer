﻿using System.Windows;

namespace RealTimeStockPriceViewer
{
    /// <summary>
    /// Interaction logic for StockPriceView.xaml
    /// </summary>
    public partial class StockPriceView : Window
    {
        public StockPriceView()
        {
            InitializeComponent();
        }
    }
}
